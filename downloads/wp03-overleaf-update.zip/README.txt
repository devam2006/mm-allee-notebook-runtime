WP03 core-scope Overleaf update - editable draft

Copy sections/03_collapse.tex and the three files in figures/ into your
CURRENT Overleaf project, preserving teammates' other sections.
This ZIP is a section update, not a full replacement project.

Keep your existing main.tex, preamble, metadata and bibliography.
The section retains bibliography keys scipy_solve_ivp, scipy_quad and
scipy_bounded from the supplied Overleaf project.
Compile the existing main.tex in Overleaf and inspect the final layout.
No compiled PDF is supplied; the figures here are EPS only.

Scope: thresholds, basins, extinction, numerical accuracy, qualitative
slow decline near critical catch, reference data and limitations.
Sensitivity, yield optimisation and asymptotic derivations are omitted.
Review and edit the section yourself before finalising it.
